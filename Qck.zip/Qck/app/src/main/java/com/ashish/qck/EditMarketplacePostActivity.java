package com.ashish.qck;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.sql.Timestamp;
import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class EditMarketplacePostActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    DownloadAd download;


    TextInputLayout textInputAdTitle, textInputAdDescription, textInputPrice;
    EditText editTextTitle, editTextAdDescription, editTextPrice;
    RadioGroup radioGroup;
    int radioButtonIndex;
    RadioButton radioButton;
    ImageView imageViewOne, imageViewTwo;
    TextView textViewImageOne, textViewImageTwo;
    Button buttonEditPost;
    StorageTask mUploadTask;
    String category;
    String ad_title, ad_description, ad_price, ad_category, id_user, id_ad;
    long ad_date, edit_date;
    Upload upload;

    private Uri imageUriOne, imageUriTwo, imageUriThree;
    private static final int IMAGE_PICK_ONE = 42;
    private static final int IMAGE_PICK_TWO = 43;
    private StorageReference storageReference;
    private FirebaseFirestore firebaseFirestore;
    private StorageReference fileReference, fileReferenceTwo;
    private final static String COLLECTION_NAME = "marketplace_posts";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_marketplace_post);

        getSupportActionBar().setTitle("QuAck - Edit Marketplace Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        Intent intent = getIntent();
        download = (DownloadAd) intent.getSerializableExtra("ad");

        //check if the current logged in user is the same as who posted the Ad
        mAuth = FirebaseAuth.getInstance();
        if (!mAuth.getCurrentUser().getUid().equals(download.getIdUser())) {
            Toast.makeText(this, "You cannot edit this Ad", Toast.LENGTH_SHORT).show();
            Intent intentHome = new Intent(this, HomepageActivity.class);
            startActivity(intentHome);
            return;
        }

        textViewImageOne = findViewById(R.id.textViewImageOne);
        textViewImageTwo = findViewById(R.id.textViewImageTwo);

        imageViewOne = findViewById(R.id.image_one);
        imageViewTwo = findViewById(R.id.image_two);

        textInputAdTitle = findViewById(R.id.textInputAdTitle);
        textInputAdTitle.getEditText().setText(download.getAdTitle());

        textInputPrice = findViewById(R.id.textInputPrice);
        textInputPrice.getEditText().setText(download.getAdPrice());

        textInputAdDescription = findViewById(R.id.textInputAdDescription);
        textInputAdDescription.getEditText().setText(download.getAdDescription());

        editTextTitle = textInputAdTitle.getEditText();
        editTextAdDescription = textInputAdDescription.getEditText();
        editTextPrice = textInputPrice.getEditText();

        category = download.getAdCategory();

        radioGroup = findViewById(R.id.radioGroupEditAd);

        buttonEditPost = findViewById(R.id.buttonEditPost);

        buttonEditPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toast.makeText(EditMarketplacePostActivity.this, "Upload in progress", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    Boolean validate = validateUserInput();
                    if (validate) {
                        updatePost();
                    }
                }
            }
        });

        //Choose image one
        textViewImageOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textViewImageOne.getText().toString().equals("Delete image")) {
                    imageUriOne = null;
                    imageViewOne.setImageDrawable(null);

                    textViewImageOne.setText("Choose image");
                } else if (textViewImageOne.getText().toString().equals("Choose image")) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, IMAGE_PICK_ONE);
                }
            }
        });

        //Choose image two
        textViewImageTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textViewImageTwo.getText().toString().equals("Delete image")) {
                    imageUriTwo = null;
                    imageViewTwo.setImageDrawable(null);
                    textViewImageTwo.setText("Choose image");
                } else if (textViewImageTwo.getText().toString().equals("Choose image")) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, IMAGE_PICK_TWO);
                }
            }
        });


        fillCurrentValues();


    }

    private void fillCurrentValues() {


        switch (category) {
            case "Books":
                ((RadioButton) radioGroup.getChildAt(0)).setChecked(true);
                Toast.makeText(this, category, Toast.LENGTH_SHORT).show();
            case "Electronics":
                radioGroup.check(R.id.radio_electronics_edit_ad);
            case "Furniture":
                radioGroup.check(R.id.radio_furniture_edit_ad);
            case "Miscellaneous":
                radioGroup.check(R.id.radio_miscellaneous_edit_ad);

        }
        /*
        HashMap<String, String> map = new HashMap<>();
        map = download.getImagesList();
        */

        String imageOne = download.getImageOne();
        String imageTwo = download.getImageTwo();
        String imageThree = download.getImageThree();


        if (!imageOne.equals("null")) {
            Picasso.get()
                    .load(imageOne)
                    .fit()
                    .centerCrop()
                    .into((ImageView) findViewById(R.id.image_one));

            textViewImageOne.setText("Delete image");
        } else {
            textViewImageOne.setText("Choose image");
        }


        if (!imageTwo.equals("null")) {
            Picasso.get()
                    .load(imageTwo)
                    .fit()
                    .centerCrop()
                    .into((ImageView) findViewById(R.id.image_two));

            textViewImageTwo.setText("Delete image");

        } else {
            textViewImageTwo.setText("Choose image");
        }

        if (!imageOne.equals("null")) {
            Picasso.get()
                    .load(imageOne)
                    .fit()
                    .centerCrop()
                    .into((ImageView) findViewById(R.id.image_one));

            textViewImageOne.setText("Delete image");
        } else {
            textViewImageOne.setText("Choose image");
        }


        if (!imageThree.equals("null")) {
            Picasso.get()
                    .load(imageThree)
                    .fit()
                    .centerCrop()
                    .into((ImageView) findViewById(R.id.image_three));

            textViewImageTwo.setText("Delete image");

        } else {
            textViewImageTwo.setText("Choose image");
        }

    }

    private void updatePost() {

        storageReference = FirebaseStorage.getInstance().getReference("marketplace_images");
        firebaseFirestore = FirebaseFirestore.getInstance();

        final HashMap<String, String> hMap = new HashMap<>();


        id_user = download.getIdUser();
        ad_title = editTextTitle.getText().toString();
        ad_description = editTextAdDescription.getText().toString();
        ad_price = editTextPrice.getText().toString();

        radioButtonIndex = radioGroup.getCheckedRadioButtonId();
        radioButton = radioGroup.findViewById(radioButtonIndex);
        ad_category = radioButton.getText().toString();

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        ad_date = download.getAdDate();
        edit_date = timestamp.getTime(); //When the post is created, ad_date and edit_date will be the same


        //id_ad = databaseReference.push().getKey();
        //id_ad = download.getIdAd();

        //************ Upload images *****************//
        if (imageUriOne != null) {

            fileReference = storageReference.child(id_user).child(id_ad).child(System.currentTimeMillis() + "." + getExtension(imageUriOne));

            mUploadTask = fileReference.putFile(imageUriOne)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {


                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Uri downloadUrl = uri;
                                    hMap.put("imageOne", downloadUrl.toString());
                                    HashMap<String, Object> map = new HashMap();
                                    map.put("imagesList", hMap);
                                    // databaseReference.child(id_ad).updateChildren(map);
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                                    //Do what you want with the url
                                    //Toast.makeText(PostAdActivity.this, downloadUrl.toString(), Toast.LENGTH_LONG).show();
                                }

                            });
                            //Toast.makeText(PostAdActivity.this,"image one uploaded",Toast.LENGTH_SHORT).show();

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            hMap.put("imageOne", "null");
                            HashMap<String, Object> map = new HashMap();
                            map.put("imagesList", hMap);
                            //databaseReference.child(id_ad).updateChildren(map);
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                            Toast.makeText(EditMarketplacePostActivity.this, "image one not uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else { //No image One selected, put "null"

            hMap.put("imageOne", "null");
            HashMap<String, Object> map = new HashMap();
            map.put("imagesList", hMap);
            //databaseReference.child(id_ad).updateChildren(map);
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(map, SetOptions.merge());
        }

        if (imageUriTwo != null) {

            fileReferenceTwo = storageReference.child(id_user).child(id_ad).child(System.currentTimeMillis() + "." + getExtension(imageUriTwo));
            mUploadTask = fileReferenceTwo.putFile(imageUriTwo)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            fileReferenceTwo.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Uri downloadUrl = uri;
                                    hMap.put("imageTwo", downloadUrl.toString());
                                    HashMap<String, Object> map = new HashMap();
                                    map.put("imagesList", hMap);
                                    //databaseReference.child(id_ad).updateChildren(map);
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                                    //Do what you want with the url
                                    //Toast.makeText(PostAdActivity.this, downloadUrl.toString(), Toast.LENGTH_LONG).show();
                                }

                            });

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            hMap.put("imageTwo", "null");
                            HashMap<String, Object> map = new HashMap();
                            map.put("imagesList", hMap);
                            //databaseReference.child(id_ad).updateChildren(map);
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                            Toast.makeText(EditMarketplacePostActivity.this, "Image two not uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            hMap.put("imageTwo", "null");
            HashMap<String, Object> map = new HashMap();
            map.put("imagesList", hMap);
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(map, SetOptions.merge());
            Toast.makeText(EditMarketplacePostActivity.this, "Image two not selected", Toast.LENGTH_SHORT).show();
            //databaseReference.child(id_ad).updateChildren(map);
        }


        //*********** Upload Ad details ***************//

        upload = new Upload(id_user, "active", ad_category, ad_title, ad_description, ad_price, ad_date, edit_date);
        //databaseReference.child(id_user).child(id_ad).setValue(upload)

        firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(upload, SetOptions.merge())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(EditMarketplacePostActivity.this, "Ad posted", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    //The back arrow must work the same as the back button on android toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_PICK_ONE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUriOne = data.getData();

            Picasso.get()
                    .load(imageUriOne)
                    .fit()
                    .centerCrop()
                    .into(imageViewOne);

            textViewImageOne.setText("Delete image");
        }

        if (requestCode == IMAGE_PICK_TWO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUriTwo = data.getData();

            Picasso.get()
                    .load(imageUriTwo)
                    .fit()
                    .centerCrop()
                    .into(imageViewTwo);

            textViewImageTwo.setText("Delete image");
        }

    }

    private boolean validateUserInput() {

        if (editTextTitle.getText().toString().trim().equals("")) {
            editTextTitle.setError("Please enter Ad title");
            return false;
        }

        if (editTextAdDescription.getText().toString().trim().equals("")) {
            editTextAdDescription.setError("Ad description cannot blank");
            return false;
        }


        if (editTextPrice.getText().toString().trim().equals("")) {
            editTextPrice.setError("Please enter product price");
            return false;
        }

        //HAVE TO ADD VALIDATION FOR NUMERICAL PRICE
        if (editTextTitle.getText().toString().length() > 100) {
            editTextTitle.setError("Ad title length cannot be over 100 characters");
            return false;
        }


        if (editTextAdDescription.getText().toString().length() > 300) {
            editTextTitle.setError("Ad description length cannot be over 300 characters");
            return false;
        }

        return true;

    }

    //return file type of image
    private String getExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
}
