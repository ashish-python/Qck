package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.annotation.Nullable;


public class SocialFragment extends Fragment {

    private FirebaseAuth mAuth;
    //private DatabaseReference databaseReference, dbr;
    String uid;
    View thisView;
    List<DownloadSocial> adList;
    private DownloadSocial download;

    private CollectionReference collectionRef;
    private ListenerRegistration changeListener;
    private static final String COLLECTION_NAME = "social_posts";



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_housing, container, false);
        setHasOptionsMenu(true);
        thisView = view;
        adList = new ArrayList<>();
        mAuth = FirebaseAuth.getInstance();
        uid = mAuth.getCurrentUser().getUid();

        collectionRef = FirebaseFirestore.getInstance().collection(COLLECTION_NAME);

        //Set Actionbar title
        ((HomepageActivity)getActivity()).getSupportActionBar().setTitle("QuAck - Social");


        return view;

    }

    @Override
    public void onStart() {
        super.onStart();



        changeListener = collectionRef.whereEqualTo("adStatus","active").orderBy("editDate", Query.Direction.DESCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if(e != null){
                    Log.d("ERROR",e.getMessage());
                    Toast.makeText(SocialFragment.this.getContext(),"Error in loading document",Toast.LENGTH_SHORT).show();
                    return;
                }

                adList.clear();

                for(QueryDocumentSnapshot adSnapshot: queryDocumentSnapshots){

                    download = adSnapshot.toObject(DownloadSocial.class);
                    adList.add(download);

                }//for loop close

                //set Adapter
                AdapterSocial adapterSocial = new AdapterSocial(SocialFragment.this.getActivity(),adList);

                ListView listViewSocial = SocialFragment.this.getActivity().findViewById(R.id.list_view_marketplace);

                //Toast.makeText(MarketplaceFragment.this.getContext(),String.valueOf(adList.size()),Toast.LENGTH_SHORT).show();
                listViewSocial.setAdapter(adapterSocial);

                listViewSocial.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent intent = new Intent(getContext(), ShowSocialAdDetailsActivity.class);
                        intent.putExtra("ad",adList.get(i));
                        startActivity(intent);

                    }
                });


            } //onEvent close
        });



    }

    @Override
    public void onStop() {
        super.onStop();
        changeListener.remove();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_social, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.post_ad:
                startActivity(new Intent(getContext(), PostSocialActivity.class));
        }
        return true;
    }


}
