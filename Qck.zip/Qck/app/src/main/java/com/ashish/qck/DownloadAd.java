package com.ashish.qck;

import java.io.Serializable;
import java.util.HashMap;

public class DownloadAd implements Serializable {

    //String idAd;
    String idUser;
    String adStatus;
    String adCategory;
    String adTitle;
    String adDescription;
    String adPrice;
    long adDate,editDate;
    HashMap<String,String> imagesList;

    String imageOne = "null",imageTwo="null",imageThree="null";

    public DownloadAd() {
        //required
    }

    //images selected to upload
    public DownloadAd(String idUser, String idAd, String adStatus, String adCategory, String adTitle, String adDescription, String adPrice, long adDate, long editDate, long negativeAdDate, long negativeEditDate, String imageOne,String imageTwo, String imageThree) {
        //this.idAd = idAd;
        this.idUser = idUser;
        this.adStatus = adStatus;
        this.adCategory = adCategory;
        this.adTitle = adTitle;
        this.adDescription = adDescription;
        this.adPrice = adPrice;
        this.adDate = adDate;
        this.editDate = editDate;
        this.imageOne = imageOne;
        this.imageTwo = imageTwo;
        this.imageThree = imageThree;
        //this.imagesList = imagesList;
    }

    public String getImageOne() {
        return imageOne;
    }

    public void setImageOne(String imageOne) {
        this.imageOne = imageOne;
    }

    public String getImageTwo() {
        return imageTwo;
    }

    public void setImageTwo(String imageTwo) {
        this.imageTwo = imageTwo;
    }

    public String getImageThree() {
        return imageThree;
    }

    public void setImageThree(String imageThree) {
        this.imageThree = imageThree;
    }



    /*

    public HashMap<String, String> getImagesList() {
        return imagesList;
    }

     public void setImagesList(HashMap<String, String> imagesList) {
        this.imagesList = imagesList;
    }

    public String getIdAd() {
        return idAd;
    }

    public void setIdAd(String idAd) {
        this.idAd = idAd;
    }
    */
    public long getEditDate() {
        return editDate;
    }

    public String getIdUser() {
        return idUser;
    }

    public String getAdStatus() {
        return adStatus;
    }

    public String getAdCategory() {
        return adCategory;
    }

    public String getAdTitle() {
        return adTitle;
    }

    public String getAdDescription() {
        return adDescription;
    }

    public long getAdDate() {
        return adDate;
    }

    public String getAdPrice() {
        return adPrice;
    }



    public void setEditDate(long editDate) {
        this.editDate = editDate;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public void setAdStatus(String adStatus) {
        this.adStatus = adStatus;
    }

    public void setAdCategory(String adCategory) {
        this.adCategory = adCategory;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
    }

    public void setAdDescription(String adDescription) {
        this.adDescription = adDescription;
    }

    public void setAdDate(long adDate) {
        this.adDate = adDate;
    }

    public void setAdPrice(String adPrice) {
        this.adPrice = adPrice;
    }


}
