package com.ashish.qck;

import java.io.Serializable;

public class DownloadSocial implements Serializable {

    //String idAd;
    String idUser;
    String adStatus;
    String adCategory;
    String adTitle;
    String adDescription;
    long eventDate1;
    long adDate,editDate;
    String imageOne = "null",imageTwo="null",imageThree = "null";
    //HashMap<String,String> imagesList;

    public DownloadSocial() {
        //required
    }

    //images selected to upload
    public DownloadSocial(String idUser, String adStatus, String adCategory, String adTitle, String adDescription, long eventDate, long adDate, long editDate, String imageOne,String imageTwo, String imageThree) {
        //this.idAd = idAd;
        this.idUser = idUser;
        this.adStatus = adStatus;
        this.adCategory = adCategory;
        this.adTitle = adTitle;
        this.adDescription = adDescription;
        this.eventDate1 = eventDate;
        this.adDate = adDate;
        this.editDate = editDate;
        //this.imagesList = imagesList;
        this.imageOne = imageOne;
        this.imageTwo = imageTwo;
        this.imageThree = imageThree;
    }


    /*
    public HashMap<String, String> getImagesList() {
        return imagesList;
    }


    public void setImagesList(HashMap<String, String> imagesList) {
        this.imagesList = imagesList;
    }

    public String getIdAd() {
        return idAd;
    }
    public void setIdAd(String idAd) {
        this.idAd = idAd;
    }

    */

    public String getImageOne() {
        return imageOne;
    }

    public void setImageOne(String imageOne) {
        this.imageOne = imageOne;
    }

    public String getImageTwo() {
        return imageTwo;
    }

    public void setImageTwo(String imageTwo) {
        this.imageTwo = imageTwo;
    }

    public String getImageThree() {
        return imageThree;
    }

    public void setImageThree(String imageThree) {
        this.imageThree = imageThree;
    }

    public long getEditDate() {
        return editDate;
    }

    public String getIdUser() {
        return idUser;
    }

    public String getAdStatus() {
        return adStatus;
    }

    public String getAdCategory() {
        return adCategory;
    }

    public String getAdTitle() {
        return adTitle;
    }

    public String getAdDescription() {
        return adDescription;
    }

    public long getAdDate() {
        return adDate;
    }

    public long getEventDate() {
        return eventDate1;
    }



    public void setEditDate(long editDate) {
        this.editDate = editDate;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public void setAdStatus(String adStatus) {
        this.adStatus = adStatus;
    }

    public void setAdCategory(String adCategory) {
        this.adCategory = adCategory;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
    }

    public void setAdDescription(String adDescription) {
        this.adDescription = adDescription;
    }

    public void setAdDate(long adDate) {
        this.adDate = adDate;
    }

    public void setEventDate(long eventDate) {
        this.eventDate1 = eventDate;
    }

}
