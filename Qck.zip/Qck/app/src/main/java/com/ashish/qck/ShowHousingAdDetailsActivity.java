package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class ShowHousingAdDetailsActivity extends AppCompatActivity {


    FirebaseAuth mAuth;
    DownloadHousing download;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_housing_ad_details);

        HashMap<String,String> map = new HashMap<>();
        getSupportActionBar().setTitle("QuAck - Housing post details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        download = (DownloadHousing)intent.getSerializableExtra("ad");

        ArrayList<String> imageURLs = new ArrayList<String>();

        //HashMap<String,String> hMap = new HashMap<>();
        //hMap = download.getImagesList();

        mAuth = FirebaseAuth.getInstance();

        String imageOne = download.getImageOne();
        String imageTwo = download.getImageTwo();
        String imageThree = download.getImageThree();

        if(!imageOne.equals("null"))
            imageURLs.add(imageOne);
        if(!imageTwo.equals("null"))
            imageURLs.add(imageTwo);
        if(!imageThree.equals("null"))
            imageURLs.add(imageThree);

        /*
        if(hMap.containsKey("imageOne") && !(hMap.get("imageOne").equals("null")))
            imageURLs.add(hMap.get("imageOne"));

        if(hMap.containsKey("imageTwo") && !(hMap.get("imageTwo").equals("null")))
            imageURLs.add(hMap.get("imageTwo"));

        if(hMap.containsKey("imageThree") && !(hMap.get("imageThree").equals("null")))
            imageURLs.add(hMap.get("imageThree"));
        */

        ViewPager viewPager = findViewById(R.id.viewPager);
        AdapterViewPager adapter = new AdapterViewPager(this,imageURLs);
        viewPager.setAdapter(adapter);

        TextView textViewUser = findViewById(R.id.textViewUsername);
        textViewUser.setText(mAuth.getCurrentUser().getEmail());

        TextView textViewTitle = findViewById(R.id.textViewTitle);
        textViewTitle.setText(download.getAdTitle());

        TextView textViewZip = findViewById(R.id.textViewZip);
        textViewZip.setText(download.getZip());

        TextView textViewRent = findViewById(R.id.textViewRent);
        //textViewRent.setText("XXX");
        textViewRent.setText(download.getAdRent());


        TextView textViewDescription = findViewById(R.id.textViewDescription);
        textViewDescription.setText(download.getAdDescription());

        String date = new SimpleDateFormat("MM-dd-yyyy").format(new Date(download.getEditDate()));

        TextView textViewDate = findViewById(R.id.textViewDate);
        textViewDate.setText(date);

        //check if the current logged in user is the same as who posted the Ad
        if(mAuth.getCurrentUser().getUid().equals(download.getIdUser())){
            Button buttonEditPost = findViewById(R.id.buttonEditPost);
            buttonEditPost.setVisibility(View.VISIBLE);
        }


    }



    public void editMarketplacePost(View view){
        Intent intent = new Intent(this,EditMarketplacePostActivity.class);
        intent.putExtra("ad",download);
        startActivity(intent);
    }



    //The back arrow must work the same as the back button on android toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
