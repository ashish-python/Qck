package com.ashish.qck;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class AdapterHousing extends ArrayAdapter<DownloadHousing> {

    private Activity context;
    private List<DownloadHousing> download;
    private FirebaseAuth mAuth;

    public AdapterHousing(Activity context, List<DownloadHousing> download){
        super(context,R.layout.list_marketplace,download);

        this.context = context;
        this.download = download;
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        View view = inflater.inflate(R.layout.list_marketplace,null);

        HashMap<String,String> hMap = new HashMap<>();

        TextView textViewTitle = view.findViewById(R.id.textViewTitle);
        TextView textViewPostedOn = view.findViewById(R.id.textViewPostedOn);
        ImageView imageView = view.findViewById(R.id.imageView);
        TextView textViewDescription = view.findViewById(R.id.textViewDescription);
        TextView textViewUser = view.findViewById(R.id.textViewUser);


        DownloadHousing ad = download.get(position);

        String date = new SimpleDateFormat("MM-dd-yyyy").format(new Date(ad.getAdDate()));

        //hMap = ad.getImagesList();

        textViewTitle.setText(ad.getAdTitle());
        textViewPostedOn.setText(date);
        textViewDescription.setText(ad.getAdDescription()); //substring this to fewer characters later

        textViewUser.setText("Posted by: " + mAuth.getCurrentUser().getEmail());

        if(ad.getImageOne()!="null")
            displayImage(ad.getImageOne(),imageView);
        else if(ad.getImageTwo()!="null")
            displayImage(ad.getImageTwo(),imageView);
        else if(ad.getImageTwo()!="null")
            displayImage(ad.getImageThree(),imageView);


        /*
        if(hMap.containsKey("imageOne") && !hMap.get("imageOne").equals("null"))
            displayImage(hMap.get("imageOne"),imageView);
        else if(hMap.containsKey("imageTwo") && !hMap.get("imageTwo").equals("null"))
            displayImage(hMap.get("imageTwo"),imageView);
        else if(hMap.containsKey("imageThree") && !hMap.get("imageThree").equals("null"))
            displayImage(hMap.get("imageThree"),imageView);
        */
        return view;
    }

    private void displayImage(String url,ImageView imageView){

        Picasso.get()
                .load(url)
                .fit()
                .centerCrop()
                .into(imageView);

    }
}
